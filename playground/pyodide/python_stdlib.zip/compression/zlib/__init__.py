import zlib
__doc__ = zlib.__doc__
del zlib

from zlib import *
