from .compilers.C import unix

UnixCCompiler = unix.Compiler
